package Enum;

/**
 *
 * @author Riguel Figueiro
 */
public class Enum {
    
    public enum TipoParada{
        
        Abastecimento,
        Descanso,
        AbastecimentoDescanso
    }
}
