package Model;

import Enum.Enum.TipoParada;

/**
 *
 * @author Riguel Figueiro
 */
public class ParadaModel {
    
    private TipoParada tipoParada;

    public TipoParada getTipoParada() {
        return tipoParada;
    }

    public void setTipoParada(TipoParada tipoParada) {
        this.tipoParada = tipoParada;
    }
}
