/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package View;

import java.io.DataInputStream;
import java.io.IOException;

/**
 *
 * @author DKO
 */
public class Menu {
    
    public void ImprimeMenu() throws IOException{
        
        System.out.println("=========================================");
        System.out.println("===============| Dijkstra |==============");
        System.out.println("=========================================");
        
        System.out.println("========| Valores válidos 0 ~ 49| =======");
        
    }
}
