package App;

import Controller.DijkstraController;
import Model.GrafoModel;
import Model.VerticeModel;
import Service.Arquivo;
import Service.Dijkstra;
import View.FormDestino;
import View.FormOrigem;
import View.Menu;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Riguel Figueiro
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        
        new Menu().ImprimeMenu();
        String origem = new FormOrigem().ImprimeFormOrigem();
        String destino = new FormDestino().ImprimeFormDestino();
                
        System.out.println();
        System.out.print("========================================");
        GrafoModel grafoPrincipal = new GrafoModel();
        grafoPrincipal = new GrafoModel();
        
        VerticeModel verticeOrigem = new VerticeModel();
        VerticeModel verticeDestino = new VerticeModel();

        // obtem os vertices do arquivo
        grafoPrincipal.setVertices(new DijkstraController().ObtemVertices());
        
        verticeOrigem = grafoPrincipal.encontrarVertice(origem);
        verticeDestino = grafoPrincipal.encontrarVertice(destino);

        System.out.println();
        List<VerticeModel> resultado = new DijkstraController().ObterMenorCaminho(grafoPrincipal, verticeOrigem, verticeDestino);

        System.out.println("Esse é o menor caminho feito pelo algoritmo:" + resultado);
    }
}
